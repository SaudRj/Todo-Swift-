//
//  ContentView.swift
//  Event CountDown
//
//  Created by Abo Rajhi on 26/12/1445 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        EventView()
    }
}

#Preview {
    ContentView()
}

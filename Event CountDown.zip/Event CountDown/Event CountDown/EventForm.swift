//
//  EventForm.swift
//  Event CountDown
//
//  Created by Abo Rajhi on 26/12/1445 AH.
//

import SwiftUI

struct Event: Identifiable, Comparable {
    var id: UUID = UUID()
    var title: String
    var date: Date
    var color: Color
    
    static func < (lhs: Event, rhs: Event) -> Bool {
        lhs.date < rhs.date
    }
    
}

enum Mode { case add, edit(Event) }

struct EventForm: View {
    
    @Binding var arrEvent: [Event]
    @State var currentMode: Mode
    
    @State var e1: Event = Event(title: "", date: Date(), color: Color.black)
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationStack{
            switch currentMode {
            case .add:
                Form {
                        Section("Event Info") {
                            TextField("Enter Event's title ", text: $e1.title)
                                .foregroundStyle(e1.color)
                                .bold()
                            DatePicker("Enter a date", selection: $e1.date)
                                .foregroundStyle(e1.color)
                            ColorPicker("Choose a color", selection: $e1.color)
                                .foregroundStyle(e1.color)
                        }
                    
                }
                .tint(e1.color)
                .navigationTitle("Add Event")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                        Button(action: {
                            onSave(e2: e1)
                        }, label: {
                            Image(systemName: "plus.circle.fill")
                                .fontWeight(.bold)
                                .foregroundStyle(e1.title.isEmpty ? Color.gray : Color.blue)
                        })
                        .disabled(e1.title.isEmpty ? true : false)
                    
                }

            case .edit(var eventFromRootView): Text("")
               Form {
                       Section("Event Info") {
                           TextField("Enter Event's title ", text: $eventFromRootView.title)
                               .foregroundStyle(eventFromRootView.color)
                               .bold()
                           DatePicker("Enter a date", selection: $eventFromRootView.date)
                               .foregroundStyle(eventFromRootView.color)
                           ColorPicker("Choose a color", selection: $eventFromRootView.color)
                               .foregroundStyle(eventFromRootView.color)
                       }
               
               }
               .tint(eventFromRootView.color)
               .navigationTitle("Edit \(eventFromRootView.title)")
               .navigationBarTitleDisplayMode(.inline)
               .toolbar {
                       Button(action: {
                           onSave(e2: eventFromRootView)
                           print("i have arrived 1")
                       }, label: {
                           Image(systemName: "arrow.down.square")
                               .fontWeight(.bold)
                               .foregroundStyle(eventFromRootView.title.isEmpty ? Color.gray : Color.blue)
                       })
                       .disabled(eventFromRootView.title.isEmpty ? true : false)
                   
               }

            }
        }
    }
        func onSave(e2 : Event){
            if case .add = currentMode
            {
                arrEvent.append(e2)
                //arrEvent.sorted()

            }
            else if case .edit = currentMode
            {
                print("i have arrived 2")
                if let index = arrEvent.firstIndex(of: e2)
                {
                    print("i have arrived 3")
                    arrEvent[index] = e2
                }
                //arrEvent.sorted()
            }
        self.presentationMode.wrappedValue.dismiss()
    }
}

#Preview {
    EventForm(arrEvent: .constant([
                    Event(title: "", date: Date.now, color: Color.red),
                    Event(title: "", date: Date.now, color: Color.red)
    ]), currentMode: .add)
}


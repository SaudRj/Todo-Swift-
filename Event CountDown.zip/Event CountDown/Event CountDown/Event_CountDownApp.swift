//
//  Event_CountDownApp.swift
//  Event CountDown
//
//  Created by Abo Rajhi on 26/12/1445 AH.
//

import SwiftUI

@main
struct Event_CountDownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
